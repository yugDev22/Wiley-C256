package com.yugam.demo;

public class DoublyLinkedList<T> {

	class Node{
		T data;
		Node prev;
		Node next;
		
		public Node(T data) {
			this.data=data;
			prev=null;
			next=null;
		}
	}
	Node head;
	
	public void insertElement(T data) {
		Node newNode = new Node(data);
		Node curr = head;
		if(head==null) {
			head=newNode;
			return;
		}
		while(curr.next!=null) {
			curr=curr.next;
		}
		newNode.prev=curr;
		curr.next=newNode;
		
	}
	
	public void deleteElement(T data) {
		Node newNode = new Node(data);
		Node curr = head;
		//head is null
		if(head==null) {
			System.out.println("Empty list");
			return;
		}
		while(curr!=null) {
			if(curr.data==data)
				break;
			curr=curr.next;
		}
		//only single node
		if(curr.prev==null&&curr.next==null) {
			head=null;
			return;
		}
		//last node
		if(curr.next==null&&curr.prev!=null) {
			curr.prev.next=null;
			curr.prev=null;
			return;
		}
		//first node
		if(curr.prev==null&&curr.next!=null) {
			head=curr.next;
			curr.next.prev=null;
			curr.next=null;
			return;
		}
		//else
		curr.prev.next = curr.next;
		curr.next.prev = curr.prev;
		
	}
	
	public void displayList() {
		Node curr = head;
		while(curr!=null) {
			System.out.print(curr.data+" ");
			curr=curr.next;
		}
	}
}
