package com.yugam.demo;

public class Main {

	public static void main(String[] args) {
		Queue<Integer> queue = new Queue<>();
		System.out.println("Enqueue 10");
		queue.enQueue(10);
		System.out.println("Enqueue 20");
		queue.enQueue(20);
		System.out.println("Enqueue 30");
		queue.enQueue(30);
		System.out.println("Enqueue 40");
		queue.enQueue(40);
		System.out.println("display queue: ");
		queue.displayQueue();
		System.out.println("\n-----------");
		System.out.println("De-Queue");
		queue.deQueue();
		System.out.println("display queue: ");
		queue.displayQueue();
		System.out.println("\nDe-Queue");
		queue.deQueue();
		System.out.println("display queue: ");
		queue.displayQueue();
		System.out.println("\nDe-Queue");
		queue.deQueue();
		System.out.println("display queue: ");
		queue.displayQueue();
		System.out.println("\nDe-Queue");
		queue.deQueue();
		System.out.println("display queue: ");
		queue.displayQueue();
		System.out.println("\nDe-Queue");
		queue.deQueue();
		System.out.println("display queue: ");
		queue.displayQueue();
	}

}
