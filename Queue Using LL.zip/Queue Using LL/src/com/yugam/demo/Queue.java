package com.yugam.demo;

import java.util.Optional;

public class Queue<T>{

	class Node{
		T data;
		Node next;
		
		Node(T data){
			this.data=data;
			this.next=null;
		}
	}
	
	Node first;
	Node last;
	
	public void enQueue(T data) {
		Node newNode = new Node(data);
		if(last==null) {
			first=newNode;
		}
		newNode.next=last;
		last=newNode;
	}
	
	public Optional<T> deQueue(){
		Node curr=last;
		Optional<T> opt;
		if(first!=null) {
			while(curr.next!=null&&curr.next!=first) {
				curr=curr.next;
			}
			if(curr.next==null) {
				opt = Optional.of(first.data);
				last=null;
				first=null;
				return opt;
			}
			opt = Optional.of(first.data);
			first=curr;
			curr.next=null;
			return opt;
		}
		return Optional.empty();
	}
	
	public void displayQueue() {
		Node curr = last;
		while(curr!=null) {
			System.out.print(curr.data+" ");
			curr=curr.next;
		}
	}
}
