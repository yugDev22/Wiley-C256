package com.yugam.demo;

import java.util.Optional;

public class LinkedList<T> {
	
	class Node{
		T data;
		Node next;
		
		Node(T data){
			this.data=data;
			this.next=null;
		}
	}
	
	Node head;
	
	public void insertElement(T data) {
		Node newNode=new Node(data);
		
		//if list is blank
		if(head==null) {
			head=newNode;
		}
		else {
			Node last=head;
			while(last.next!=null) {
				last=last.next;
			}
			last.next=newNode;
		}
		
	}
	
	public void displayList() {
		Node currentNode=head;
		while(currentNode!=null) {
			System.out.print(currentNode.data+" ");
			currentNode=currentNode.next;
		}
	}
	
	public void deleteElement(T data) {
		Node currentNode = head;
		Node prev = null;
		//if list is empty
		if(head==null) {
			System.out.println("Empty list");
			return;
		}
		else if(currentNode!=null&&currentNode.data==data) {
			head=currentNode.next;
			return;
		}
		while(currentNode!=null && currentNode.data!=data) {
			prev=currentNode;
			currentNode=currentNode.next;
		}
		
		if(currentNode==null)
			return;
		
		prev.next=currentNode.next;
			
	}
	
	public void displayReverse() {
		Stack<T> stack = new Stack<>();
		Node currentNode=head;
		while(currentNode!=null) {
			stack.push(currentNode.data);
			currentNode=currentNode.next;
		}
		Optional<T> opt = stack.pop();
		System.out.println("Reverse order linked list: ");
		while(opt.isPresent()) {
			System.out.print(opt.get()+" ");
			opt = stack.pop();
		}
	}
}
