package com.yugam.demo;

import java.util.Optional;
import java.util.Scanner;

public class ReverseClient {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		LinkedList<Integer> linkedList = new LinkedList<>();
		while(true) {
			System.out.println("---------Linked list--------");
			System.out.println("1. Enter element to list");
			System.out.println("2. Remove element from list");
			System.out.println("3. print linked list");
			System.out.println("4. print linked list in reverse order");
			System.out.println("5. exit");
			int choice = scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter element: ");
				int element = scanner.nextInt();
				linkedList.insertElement(element);
				System.out.println("inserted : "+element);
				break;
			case 2:
				System.out.println("Enter element: ");
				element = scanner.nextInt();
				linkedList.deleteElement(element);
				System.out.println("deleted : "+element);
				break;
			case 3:
				linkedList.displayList();
				System.out.println();
				break;
			case 4:
				linkedList.displayReverse();
				System.out.println();
				break;
			case 5:
				System.out.println("Thanks for using LinkedList service");
				System.exit(0);
			default:
				System.out.println("Enter valid choice");
			}
			
		}

	}

}
