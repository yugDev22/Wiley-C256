package com.yugam.demo;

import java.util.Optional;

public class Stack<T> {
	
	class Node{
		T data;
		Node next;
		public Node(T data) {
			this.data=data;
			this.next=null;
		}
	}
	
	Node top;
	
	public void push(T data) {
		Node newNode = new Node(data);
		newNode.next=top;
		top = newNode;
		
	}
	
	public Optional<T> pop() {
		if(top==null) {
			return Optional.empty();
		}
		T res = top.data;
		top=top.next;
		return Optional.ofNullable(res);
	}
	
}
