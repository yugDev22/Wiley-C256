package com.yugam.demo;

import java.util.Optional;
import java.util.Scanner;

public class StackMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Stack<Integer> stack = new Stack<>();
		while(true) {
			System.out.println("1. Push element to stack");
			System.out.println("2. Pop element from stack");
			System.out.println("3. Exit");
			int choice = scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter element to push: ");
				int element = scanner.nextInt();
				stack.push(element);
				System.out.println("Pushed : "+element);
				break;
			case 2:
				Optional<Integer> optional = stack.pop();
				if(optional.isPresent()) {
					System.out.println("Popped element: "+optional.get());
				}
				else {
					System.out.println("Empty stack");
				}
				break;
			case 3:
				System.out.println("Thanks for using stack service");
				System.exit(0);
			default:
				System.out.println("Enter valid choice");
			}
			
		}

	}

}
